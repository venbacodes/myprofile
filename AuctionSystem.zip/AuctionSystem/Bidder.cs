﻿namespace AuctionSystem
{
    class Bidder
    {
        public string Name { get; set; }
        public int StartingBid { get; set; }
        public int MaxBid { get; set; }
        public int AutoIncrementAmount { get; set; }
        public int BreakOut //number of times they can be bid without reaching their max
        {
            get
            {
                return (MaxBid - StartingBid) / AutoIncrementAmount;
            }
        }
    }
}
