﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace AuctionSystem
{
    class AuctionOperations
    {
        internal (Bidder, decimal) FindAuctionWinner(AuctionOffer auctionOffer, List<Bidder> bidders)
        {
            var winningBidder = new Bidder();

            //Remove bidders who are violating the maximum auto increment bid
            bidders.RemoveAll(b => b.AutoIncrementAmount > auctionOffer.MaxIncrementLimit);

            //Limiting the bidders within the max bidders mentioned in the auction considering the max bid amount
            if (bidders.Count > auctionOffer.MaxBidders)
            {
                bidders = bidders.OrderByDescending(o => o.MaxBid).ToList();

                bidders.RemoveRange(0, auctionOffer.MaxBidders - 1);
            }

            //Ordering the bidders based on the breakout bids they have setup
            bidders = bidders.OrderBy(o => o.BreakOut).ToList();

            var minBreakOutBidders = bidders.FindAll(f => f.BreakOut == bidders.FirstOrDefault().BreakOut);

            //If two or more bidders have same breakout bid count, choose the bidder with max bid amount
            if (minBreakOutBidders.Count > 0)
            {
                winningBidder = minBreakOutBidders.OrderByDescending(o => o.MaxBid).ToList().FirstOrDefault();
            }
            else
            {
                winningBidder = minBreakOutBidders.FirstOrDefault();
            }

            //Finding winning bid based on the breakout
            var winningBid = (winningBidder.BreakOut * winningBidder.AutoIncrementAmount) + winningBidder.StartingBid;

            return (winningBidder, winningBid);
        }
    }
}
