﻿using System;

namespace AuctionSystem
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Initializing Auction System");
            Console.WriteLine("");
            var auctionSystem = new AuctionSystem();

            Console.WriteLine("Auction Information:");
            auctionSystem.PrintAuctionInformation();

            Console.WriteLine("Bidders Information");
            auctionSystem.PrintBiddersInformation();

            Console.WriteLine("Starting Auction Algorithm");

            var auctionOperations = new AuctionOperations();
            var winningBidder = auctionOperations.FindAuctionWinner(auctionSystem.AuctionOffer, auctionSystem.Bidders);

            Console.WriteLine("Auction Ended");

            Console.WriteLine("Auction Winner: " + winningBidder.Item1.Name);
            Console.WriteLine("Winning Bid: " + winningBidder.Item2);
        }
    }
}
