﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace AuctionSystem
{
    class AuctionOperations
    {
        internal (Bidder, decimal) FindAuctionWinner(AuctionOffer auctionOffer, List<Bidder> bidders)
        {
            var winningBidder = new Bidder();

            //Remove bidders who are violating the maximum auto increment bid
            bidders.RemoveAll(b => b.AutoIncrementAmount > auctionOffer.MaxIncrementLimit);

            //Limiting the bidders within the max bidders mentioned in the auction considering the max bid amount
            if (bidders.Count > auctionOffer.MaxBidders)
            {
                bidders = bidders.OrderByDescending(o => o.MaxBid).ToList();

                bidders.RemoveRange(0, auctionOffer.MaxBidders - 1);
            }

            //Ordering the bidders based on the MaxBidbyIncrement
            bidders = bidders.OrderBy(o => o.MaxBidbyIncrement).ToList();

            //Choose first 2 highest bidders
            var firstBidder = bidders[bidders.Count - 1];
            var secondBidder = bidders[bidders.Count - 2];

            //If they have same max bid amount, choose the bidder who came first
            if (firstBidder.MaxBidbyIncrement == secondBidder.MaxBidbyIncrement)
            {
                winningBidder = FindWinningBidderbyPosition(firstBidder, secondBidder);
                return (winningBidder, winningBidder.MaxBidbyIncrement);
            }
            else
            {
                return (firstBidder, FindNearestWinningBid(firstBidder, secondBidder));
            }
        }

        internal Bidder FindWinningBidderbyPosition(Bidder firstBidder, Bidder secondBidder)
        {
            if (firstBidder.Id > secondBidder.Id)
            {
                return secondBidder;
            }
            else
            {
                return firstBidder;
            }
        }

        internal int FindNearestWinningBid(Bidder firstBidder, Bidder secondBidder)
        {
            var nextPossibleBid = secondBidder.MaxBidbyIncrement + firstBidder.AutoIncrementAmount;

            var winningBid = firstBidder.BiddingAmounts.OrderBy(o => Math.Abs(o - nextPossibleBid)).FirstOrDefault();

            return winningBid;
        }
    }
}
