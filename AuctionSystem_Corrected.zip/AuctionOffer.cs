﻿using System;

namespace AuctionSystem
{
    class AuctionOffer
    {
        public string Event { get; set; }
        public string ItemName { get; set; }
        public int BasePrice { get; set; }
        public int MaxIncrementLimit { get; set; }
        public int MaxBidders { get; set; }
        public DateTime StartTime { get; set; }
        public DateTime EndTime { get; set; }
    }
}
