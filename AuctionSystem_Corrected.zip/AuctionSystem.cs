﻿using System;
using System.Collections.Generic;

namespace AuctionSystem
{
    class AuctionSystem
    {
        public List<Bidder> Bidders;
        public AuctionOffer AuctionOffer;

        internal AuctionSystem()
        {
            AuctionOffer = new AuctionOffer
            {
                Event = "California Property - Auction Sale",
                ItemName = "Property XYZ",
                BasePrice = 50000,
                MaxIncrementLimit = 5000,
                MaxBidders = 5,
                StartTime = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 10, 0, 0),
                EndTime = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 10, 15, 0)
            };

            Bidders = new List<Bidder>()
            {
                new Bidder{ Id = 1, Name = "Buyer 1", StartingBid = 60000, MaxBid = 90000, AutoIncrementAmount = 2000 },
                new Bidder{ Id = 2, Name = "Buyer 2", StartingBid = 55000, MaxBid = 95000, AutoIncrementAmount = 1000 },
                new Bidder{ Id = 3, Name = "Buyer 3", StartingBid = 52000, MaxBid = 125000, AutoIncrementAmount = 5000 },
                new Bidder{ Id = 4, Name = "Buyer 4", StartingBid = 51000, MaxBid = 100000, AutoIncrementAmount = 2000 },
                new Bidder{ Id = 5, Name = "Buyer 5", StartingBid = 52000, MaxBid = 110000, AutoIncrementAmount = 4000 }
            };
        }

        internal void PrintBiddersInformation()
        {
            foreach(var _bidder in Bidders)
            {
                Console.WriteLine(_bidder.Name + ":" + "Starting Bid: $ " + _bidder.StartingBid + " | Max Bid: $" + _bidder.MaxBid + " | Auto Increment Amount: $" + _bidder.AutoIncrementAmount);
            }
            
            Console.WriteLine("");
        }

        internal void PrintAuctionInformation()
        {
            Console.WriteLine("Event: " + AuctionOffer.Event);
            Console.WriteLine("Name: " + AuctionOffer.ItemName);
            Console.WriteLine("Base Price: $" + AuctionOffer.BasePrice);
            Console.WriteLine("Auto Increment Limit: $" + AuctionOffer.MaxIncrementLimit);
            Console.WriteLine("Max Bidders: $" + AuctionOffer.MaxBidders);
            Console.WriteLine("Start Time: " + AuctionOffer.StartTime.ToString("HH:mm tt"));
            Console.WriteLine("End Time: " + AuctionOffer.EndTime.ToString("HH:mm tt"));
            Console.WriteLine("");
        }
    }
}
