﻿using System.Collections.Generic;

namespace AuctionSystem
{
    class Bidder
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public int StartingBid { get; set; }
        public int MaxBid { get; set; }
        public int AutoIncrementAmount { get; set; }
        public int MaxBidbyIncrement
        {
            get
            {
                var bidDiff = MaxBid - StartingBid;
                if (bidDiff % AutoIncrementAmount == 0)
                {
                    return MaxBid;
                }
                else
                {
                    return MaxBid - (bidDiff % AutoIncrementAmount);
                }
            }
        }
        public List<int> BiddingAmounts
        {
            get
            {
                var _biddingAmounts = new List<int>();

                for (int i = StartingBid; i <= MaxBid; i += AutoIncrementAmount)
                {
                    _biddingAmounts.Add(i);
                }

                return _biddingAmounts;
            }
        }
    }
}
